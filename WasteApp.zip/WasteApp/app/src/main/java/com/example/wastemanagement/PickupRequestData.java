package com.example.wastemanagement;

public class PickupRequestData {
}
