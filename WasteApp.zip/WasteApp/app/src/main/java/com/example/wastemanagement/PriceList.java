package com.example.wastemanagement;

public class PriceList {
}
