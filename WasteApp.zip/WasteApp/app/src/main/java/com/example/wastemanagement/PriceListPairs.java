package com.example.wastemanagement;

public class PriceListPairs {
}
