package com.example.wastemanagement;

public class RequestWeightsData {
    private final String categoryName;
    private final Double weight;

    public RequestWeightsData(String categoryName, Double weight) {
        this.categoryName = categoryName;
        this.weight = weight;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public Double getWeight() {
        return weight;
    }
}