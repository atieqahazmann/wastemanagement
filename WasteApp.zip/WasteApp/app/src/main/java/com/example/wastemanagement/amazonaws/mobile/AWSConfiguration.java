package com.example.wastemanagement.amazonaws.mobile;

import com.amazonaws.regions.Regions;
import com.example.wastemanagement.amazonaws.mobilehelper.config.AWSMobileHelperConfiguration;

/**
 * This class defines constants for the developer's resource
 * identifiers and API keys. This configuration should not
 * be shared or posted to any public source code repository.
 */
public class AWSConfiguration {
    // AWS MobileHub user agent string
    public static final String AWS_MOBILEHUB_USER_AGENT =
            "MobileHub 34d6fa94-00ae-4495-aaaf-7d74b5931021 aws-my-sample-app-android-v0.16";
    // AMAZON COGNITO
    public static final Regions AMAZON_COGNITO_REGION =
            Regions.fromName("us-east-1");
    public static final String  AMAZON_COGNITO_IDENTITY_POOL_ID =
            "us-east-1:16125265-854a-4eb3-ab15-9d96df2f8298";
    public static final Regions AMAZON_DYNAMODB_REGION =
            Regions.fromName("us-east-1");

    private static final AWSMobileHelperConfiguration helperConfiguration = new AWSMobileHelperConfiguration.Builder()
            .withCognitoRegion(AMAZON_COGNITO_REGION)
            .withCognitoIdentityPoolId(AMAZON_COGNITO_IDENTITY_POOL_ID)
            .build();
    /**
     * @return the configuration for AWSKit.
     */
    public static AWSMobileHelperConfiguration getAWSMobileHelperConfiguration() {
        return helperConfiguration;
    }
}