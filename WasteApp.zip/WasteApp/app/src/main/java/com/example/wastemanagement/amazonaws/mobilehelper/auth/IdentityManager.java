package com.example.wastemanagement.amazonaws.mobilehelper.auth;

import android.app.Activity;
import android.content.Context;
import android.util.Log;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.SDKGlobalConfiguration;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.CognitoCachingCredentialsProvider;
import com.example.wastemanagement.amazonaws.mobilehelper.config.AWSMobileHelperConfiguration;
import com.example.wastemanagement.amazonaws.mobilehelper.util.ThreadUtils;

import java.util.Date;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * The identity manager keeps track of the current sign-in provider and is responsible
 * for caching credentials.
 */
public class IdentityManager {

    /** Holder for the credentials provider, allowing the underlying provider to be swapped when necessary. */
    private class AWSCredentialsProviderHolder implements AWSCredentialsProvider {
        private volatile CognitoCachingCredentialsProvider underlyingProvider;

        @Override
        public AWSCredentials getCredentials() {
            return underlyingProvider.getCredentials();
        }

        @Override
        public void refresh() {
            underlyingProvider.refresh();
        }

        private CognitoCachingCredentialsProvider getUnderlyingProvider() {
            return underlyingProvider;
        }

        private void setUnderlyingProvider(final CognitoCachingCredentialsProvider underlyingProvider) {
            // if the current underlyingProvider is not null
            this.underlyingProvider = underlyingProvider;
        }
    }

    /** Log tag. */
    private static final String LOG_TAG = IdentityManager.class.getSimpleName();

    /** Holder for the credentials provider, allowing the underlying provider to be swapped when necessary. */
    private final AWSCredentialsProviderHolder credentialsProviderHolder;

    /** Application context. */
    private final Context appContext;

    private final AWSMobileHelperConfiguration awsMobileHelperConfiguration;

    /* Cognito client configuration. */
    private final ClientConfiguration clientConfiguration;

    /** Executor service for obtaining credentials in a background thread. */
    private final ExecutorService executorService = Executors.newFixedThreadPool(4);

    /**
     * Timeout CountdownLatch for doStartupAuth().
     */
    private final CountDownLatch startupAuthTimeoutLatch = new CountDownLatch(1);

    /**
     * Constructor. Initializes the Cognito credentials provider.
     * @param context the application context.
     * @param clientConfiguration the client configuration options such as retries and timeouts.
     */
    public IdentityManager(final Context context, final ClientConfiguration clientConfiguration,
                           final AWSMobileHelperConfiguration awsMobileHelperConfiguration) {
        Log.d(LOG_TAG, "IdentityManager init");
        this.appContext = context.getApplicationContext();
        this.awsMobileHelperConfiguration = awsMobileHelperConfiguration;
        this.clientConfiguration = clientConfiguration;
        credentialsProviderHolder = new AWSCredentialsProviderHolder();
        initializeCognito(this.appContext, this.clientConfiguration);
    }

    public AWSMobileHelperConfiguration getHelperConfiguration() {
        return awsMobileHelperConfiguration;
    }

    private void setCredentialsProvider(final Context context,
                                        final CognitoCachingCredentialsProvider cachingCredentialsProvider) {
        credentialsProviderHolder.setUnderlyingProvider(cachingCredentialsProvider);
    }

    private void initializeCognito(final Context context, final ClientConfiguration clientConfiguration) {
        setCredentialsProvider(context,
                new CognitoCachingCredentialsProvider(context, awsMobileHelperConfiguration.getCognitoIdentityPoolId(),
                        awsMobileHelperConfiguration.getCognitoRegion(), clientConfiguration
                ));
    }

    /**
     * @return true if the cached Cognito credentials are expired, otherwise false.
     */
    public boolean areCredentialsExpired() {

        final Date credentialsExpirationDate =
                credentialsProviderHolder.getUnderlyingProvider().getSessionCredentitalsExpiration();

        if (credentialsExpirationDate == null) {
            Log.d(LOG_TAG, "Credentials are EXPIRED.");
            return true;
        }

        long currentTime = System.currentTimeMillis() -
                (long)(SDKGlobalConfiguration.getGlobalTimeOffset() * 1000);

        final boolean credsAreExpired =
                (credentialsExpirationDate.getTime() - currentTime) < 0;

        Log.d(LOG_TAG, "Credentials are " + (credsAreExpired ? "EXPIRED." : "OK"));

        return credsAreExpired;
    }

    /**
     * @return the Cognito credentials provider.
     */
    public AWSCredentialsProvider getCredentialsProvider() {
        return this.credentialsProviderHolder;
    }

    public CognitoCachingCredentialsProvider getUnderlyingProvider() {
        return this.credentialsProviderHolder.getUnderlyingProvider();
    }

    /**
     * Gets the cached unique identifier for the user.
     * @return the cached unique identifier for the user.
     */
    public String getCachedUserID() {
        return credentialsProviderHolder.getUnderlyingProvider().getCachedIdentityId();
    }

    /**
     * Gets the user's unique identifier. This method can be called from
     * any thread.
     * @param handler handles the unique identifier for the user
     */
    public void getUserID(final IdentityHandler handler) {

        executorService.submit(new Runnable() {
            Exception exception = null;

            @Override
            public void run() {
                String identityId = null;

                try {
                    // Retrieve the user identity on the background thread.
                    identityId = credentialsProviderHolder.getUnderlyingProvider().getIdentityId();
                } catch (final Exception exception) {
                    this.exception = exception;
                    Log.e(LOG_TAG, exception.getMessage(), exception);
                } finally {
                    final String result = identityId;
                    Log.d(LOG_TAG, "Got user ID: " + identityId);

                    // Lint doesn't like early return inside a finally block, so nesting further inside the if here.
                    if (handler != null) {
                        ThreadUtils.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (exception != null) {
                                    handler.handleError(exception);
                                    return;
                                }

                                handler.onIdentityId(result);
                            }
                        });
                    }
                }
            }
        });
    }


    /**
     * @return true if Cognito credentials have been obtained with at least one provider.
     */
    public boolean isUserSignedIn() {
        final Map<String, String> logins = credentialsProviderHolder.getUnderlyingProvider().getLogins();
        if (logins == null || logins.size() == 0)
            return false;
        return true;
    }

    private void handleStartupAuthResult(final Activity callingActivity,
                                         final StartupAuthResultHandler startupAuthResultHandler,
                                         final IdentityProvider provider,
                                         final Exception providerException,
                                         final Exception unAuthException) {
        runAfterStartupAuthDelay(callingActivity, new Runnable() {
            @Override
            public void run() {
                startupAuthResultHandler.onComplete(new StartupAuthResult(IdentityManager.this,
                        new StartupAuthErrorDetails(provider, providerException, unAuthException)));
            }
        });
    }

    private void handleUnauthenticated(final Activity callingActivity,
                                       final StartupAuthResultHandler startupAuthResultHandler,
                                       final IdentityProvider provider,
                                       final Exception ex) {

        if (getCachedUserID() != null) {
            handleStartupAuthResult(callingActivity, startupAuthResultHandler, provider, ex, null);
        }

        getUserID(new IdentityHandler() {
            @Override
            public void onIdentityId(final String identityId) {
                handleStartupAuthResult(callingActivity, startupAuthResultHandler, provider, ex, null);
            }

            @Override
            public void handleError(final Exception exception) {
                handleStartupAuthResult(callingActivity, startupAuthResultHandler, provider, ex, exception);
            }
        });
    }

    /**
     * Starts an activity after the splash timeout.
     * @param runnable runnable to run after the splash timeout expires.
     */
    private void runAfterStartupAuthDelay(final Activity callingActivity, final Runnable runnable) {
        executorService.submit(new Runnable() {
            public void run() {
                // Wait for the splash timeout expiry or for the user to tap.
                try {
                    startupAuthTimeoutLatch.await();
                } catch (InterruptedException e) {
                    Log.d(LOG_TAG, "Interrupted while waiting for startup auth minimum delay.");
                }

                callingActivity.runOnUiThread(runnable);
            }
        });
    }

    /**
     * This should be called from your app's splash activity upon start-up. If the user was previously
     * signed in, this will attempt to refresh their identity using the previously sign-ed in provider.
     * If the user was not previously signed in or their identity could not be refreshed with the
     * previously signed in provider and sign-in is optional, it will attempt to obtain an unauthenticated (guest)
     * identity.
     *
     * @param callingActivity the calling activity.
     * @param startupAuthResultHandler a handler for returning results.
     * @param minimumDelay the minimum delay to wait before returning the sign-in result.
     */
    public void doStartupAuth(final Activity callingActivity,
                              final StartupAuthResultHandler startupAuthResultHandler,
                              final long minimumDelay) {

        executorService.submit(new Runnable() {
            public void run() {
                Log.d(LOG_TAG, "Starting up authentication...");
                if (minimumDelay > 0) {
                    // Wait for the splash timeout.
                    try {
                        Thread.sleep(minimumDelay);
                    } catch (final InterruptedException ex) {
                        Log.i(LOG_TAG, "Interrupted while waiting for startup auth timeout.");
                    }
                }

                // Expire the splash page delay.
                startupAuthTimeoutLatch.countDown();
            }
        });

        handleUnauthenticated(callingActivity, startupAuthResultHandler, null, null);
    }

    /**
     * This should be called from your app's splash activity upon start-up. If the user was previously
     * signed in, this will attempt to refresh their identity using the previously sign-ed in provider.
     * If the user was not previously signed in or their identity could not be refreshed with the
     * previously signed in provider and sign-in is optional, it will attempt to obtain an unauthenticated (guest)
     * identity.
     *
     * @param callingActivity the calling activity.
     * @param startupAuthResultHandler a handler for returning results.
     */
    public void doStartupAuth(final Activity callingActivity,
                              final StartupAuthResultHandler startupAuthResultHandler) {
        doStartupAuth(callingActivity, startupAuthResultHandler, 0);
    }

    /**
     * Call this to ignore waiting for the remaining timeout delay.
     */
    public void expireSignInTimeout() {
        startupAuthTimeoutLatch.countDown();
    }
}