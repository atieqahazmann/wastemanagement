package com.example.wastemanagement.amazonaws.mobilehelper.auth;

public enum IdentityProviderType {

    /**
     * Facebook
     */
    FACEBOOK,

    /**
     * Google
     */
    GOOGLE,

    /**
     * Twitter
     */
    TWITTER,

    /**
     * Amazon
     */
    AMAZON,

    /**
     * Custom SAML Provider
     */
    CUSTOM_SAML,

    /**
     * Cognito User Pool
     */
    COGNITO_USER_POOL;
}
