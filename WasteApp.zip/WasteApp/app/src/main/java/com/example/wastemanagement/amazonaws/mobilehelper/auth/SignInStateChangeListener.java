package com.example.wastemanagement.amazonaws.mobilehelper.auth;

public interface SignInStateChangeListener {

    /**
     * Invoked when the user completes sign-in.
     */
    void onUserSignedIn();

    /**
     * Invoked when the user signs out.
     */
    void onUserSignedOut();
}
