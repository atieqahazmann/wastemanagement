package com.example.wastemanagement.amazonaws.mobilehelper.auth;

public interface StartupAuthResultHandler {
    /**
     * Called when the startup auth flow is complete.
     * For Optional Sign-in one of the following occurred:
     * 1. No identity was obtained.
     * 2. An unauthenticated (guest) identity was obtained.
     * 3. An authenticated identity was obtained (using an identity provider).
     *
     * @param authResults the StartupAuthResult object containing the results for doStartupAuth().
     */
    void onComplete(StartupAuthResult authResults);
}
